public class Q1Student {
    public static void main(String[] args) {
        String name = "Nikita Negi";
        int age = 18;
        String collegeName = "COER University";
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("College Name: " + collegeName);
    }
}
