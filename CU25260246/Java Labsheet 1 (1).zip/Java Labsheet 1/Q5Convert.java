import java.util.Scanner;
public class Q5Convert {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a floating-point number: ");
        double number = sc.nextDouble();

        int convertedNumber = (int) number;

        System.out.println("Original value: " + number);
        System.out.println("Converted integer value: " + convertedNumber);

        sc.close();
    }
}
