import java.util.Scanner;

public class Q25LogicalOperation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter first integer (0 or 1): ");
        int num1 = sc.nextInt();

        System.out.print("Enter second integer (0 or 1): ");
        int num2 = sc.nextInt();

        System.out.print("Enter logical operator (AND/OR/NOT): ");
        char operator = sc.next().charAt(0);

        if (operator == 'A' || operator == 'a') {
            System.out.println("Result: " + (num1 == 1 && num2 == 1));
        } else if (operator == 'O' || operator == 'o') {
            System.out.println("Result: " + (num1 == 1 || num2 == 1));
        } else if (operator == 'N' || operator == 'n') {
            System.out.println("Result: " + !(num1 == 1));
        } else {
            System.out.println("Invalid logical operator.");
        }

        sc.close();
    }
}
