import java.util.Scanner;

public class Q28NumberOfDigits {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = sc.nextInt();

        number = Math.abs(number);

        if (number < 10) {
            System.out.println("The number has 1 digit.");
        } else if (number < 100) {
            System.out.println("The number has 2 digits.");
        } else if (number < 1000) {
            System.out.println("The number has 3 digits.");
        } else if (number < 10000) {
            System.out.println("The number has 4 digits.");
        } else if (number < 100000) {
            System.out.println("The number has 5 digits.");
        } else {
            System.out.println("The number has more than 5 digits.");
        }

        sc.close();
    }
}
