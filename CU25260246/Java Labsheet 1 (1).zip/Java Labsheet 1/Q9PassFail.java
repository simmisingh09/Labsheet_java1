import java.util.Scanner;
public class Q9PassFail {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter marks of Subject 1: ");
        float marks1 = sc.nextFloat();

        System.out.print("Enter marks of Subject 2: ");
        float marks2 = sc.nextFloat();

        System.out.print("Enter marks of Subject 3: ");
        float marks3 = sc.nextFloat();

        float total = marks1 + marks2 + marks3;
        float percentage = (total / 300) * 100;

        System.out.println("Total Marks: " + total);
        System.out.println("Percentage: " + percentage + "%");

        if (marks1 >= 40 && marks2 >= 40 && marks3 >= 40) {
            System.out.println("Result: Pass");
        } else {
            System.out.println("Result: Fail");
        }

        sc.close();
    }
}
